// ============================================================================
// KALORIYA AI — Ovqat kaloriyasini rasmga qarab aniqlovchi Flutter ilovasi
// ============================================================================
//
// 1. Loyiha yaratish va paketlarni o'rnatish:
//    flutter create kaloriya_ai
//    cd kaloriya_ai
//    flutter pub add image_picker google_generative_ai shared_preferences
//
// 2. pubspec.yaml fayliga qo'shiladigan asosiy paketlar:
//    dependencies:
//      flutter:
//        sdk: flutter
//      image_picker: ^1.1.2
//      google_generative_ai: ^0.4.6
//      shared_preferences: ^2.3.2
//
// 3. Ruxsatnomalar (Permissions):
//    - Android (android/app/src/main/AndroidManifest.xml):
//      <uses-permission android:name="android.permission.INTERNET"/>
//      <uses-permission android:name="android.permission.CAMERA"/>
//    - iOS (ios/Runner/Info.plist):
//      <key>NSCameraUsageDescription</key>
//      <string>Ovqat rasmini olish uchun kameraga ruxsat bering</string>
//      <key>NSPhotoLibraryUsageDescription</key>
//      <string>Galereyadan ovqat rasmini tanlash uchun ruxsat bering</string>
//
// 4. Ishga tishi:
//    Ilova ichidagi "Sozlamalar" (yuqori o'ng burchakdagi kalit belgisi) orqali
//    Google AI Studio (aistudio.google.com) dan olingan Gemini API kalitingizni
//    kiritishingiz yoki API kalitsiz "Demo rejim" orqali milliy taomlarda
//    sinab ko'rishingiz mumkin.
// ============================================================================

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const KaloriyaAiApp());
}

class KaloriyaAiApp extends StatelessWidget {
  const KaloriyaAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kaloriya AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF10B981),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        cardTheme: CardThemeData(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFE2E8F0)),
          ),
          color: Colors.white,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

// ============================================================================
// MA'LUMOT MODELLARI (DATA MODELS)
// ============================================================================

class IngredientItem {
  final String name;
  final int grams;
  final int calories;

  const IngredientItem({
    required this.name,
    required this.grams,
    required this.calories,
  });

  factory IngredientItem.fromJson(Map<String, dynamic> json) {
    return IngredientItem(
      name: (json['name'] ?? 'Noma\'lum masalliq').toString(),
      grams: (json['grams'] as num?)?.toInt() ?? 0,
      calories: (json['calories'] as num?)?.toInt() ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'grams': grams,
        'calories': calories,
      };
}

class FoodAnalysisResult {
  final String dishName;
  final int portionGrams;
  final int totalCalories;
  final double proteinGrams;
  final double fatGrams;
  final double carbsGrams;
  final double fiberGrams;
  final int healthScore; // 1 dan 10 gacha
  final String healthAdvice;
  final List<IngredientItem> ingredients;
  final DateTime timestamp;

  FoodAnalysisResult({
    required this.dishName,
    required this.portionGrams,
    required this.totalCalories,
    required this.proteinGrams,
    required this.fatGrams,
    required this.carbsGrams,
    required this.fiberGrams,
    required this.healthScore,
    required this.healthAdvice,
    required this.ingredients,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  factory FoodAnalysisResult.fromJson(Map<String, dynamic> json) {
    final rawIngredients = json['ingredients'] as List<dynamic>? ?? [];
    return FoodAnalysisResult(
      dishName: (json['dish_name'] ?? 'Aniqlangan taom').toString(),
      portionGrams: (json['portion_grams'] as num?)?.toInt() ?? 250,
      totalCalories: (json['total_calories'] as num?)?.toInt() ?? 0,
      proteinGrams: (json['protein_g'] as num?)?.toDouble() ?? 0.0,
      fatGrams: (json['fat_g'] as num?)?.toDouble() ?? 0.0,
      carbsGrams: (json['carbs_g'] as num?)?.toDouble() ?? 0.0,
      fiberGrams: (json['fiber_g'] as num?)?.toDouble() ?? 0.0,
      healthScore: ((json['health_score'] as num?)?.toInt() ?? 7).clamp(1, 10),
      healthAdvice: (json['health_advice'] ??
              'Me\'yorida iste\'mol qilish tavsiya etiladi.')
          .toString(),
      ingredients: rawIngredients
          .whereType<Map<String, dynamic>>()
          .map(IngredientItem.fromJson)
          .toList(),
      timestamp: json['timestamp'] != null
          ? DateTime.tryParse(json['timestamp'].toString()) ?? DateTime.now()
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
        'dish_name': dishName,
        'portion_grams': portionGrams,
        'total_calories': totalCalories,
        'protein_g': proteinGrams,
        'fat_g': fatGrams,
        'carbs_g': carbsGrams,
        'fiber_g': fiberGrams,
        'health_score': healthScore,
        'health_advice': healthAdvice,
        'ingredients': ingredients.map((e) => e.toJson()).toList(),
        'timestamp': timestamp.toIso8601String(),
      };
}

// ============================================================================
// DEMO TAOMLAR BAZASI (API KALITSIZ SINAB KO'RISH UCHUN)
// ============================================================================

final List<FoodAnalysisResult> demoDishes = [
  FoodAnalysisResult(
    dishName: "To'y oshi (Palov)",
    portionGrams: 350,
    totalCalories: 745,
    proteinGrams: 28.5,
    fatGrams: 34.0,
    carbsGrams: 82.0,
    fiberGrams: 4.5,
    healthScore: 6,
    healthAdvice:
        "Palov to'yimli va quvvatga boy taom. Yog' miqdorini muvozanatlash uchun achchiq-chuchuk salati va ko'k choy bilan tanovul qilish tavsiya etiladi.",
    ingredients: const [
      IngredientItem(name: "Guruch (pishgan)", grams: 180, calories: 240),
      IngredientItem(name: "Qo'y va mol go'shti", grams: 80, calories: 235),
      IngredientItem(name: "Sabzi (sariq va qizil)", grams: 60, calories: 25),
      IngredientItem(name: "O'simlik yog'i va dumba", grams: 25, calories: 225),
      IngredientItem(name: "No'xat va mayiz", grams: 15, calories: 20),
    ],
  ),
  FoodAnalysisResult(
    dishName: "Tandir somsa (Go'shtli, 2 dona)",
    portionGrams: 220,
    totalCalories: 580,
    proteinGrams: 22.0,
    fatGrams: 31.0,
    carbsGrams: 53.0,
    fiberGrams: 2.2,
    healthScore: 5,
    healthAdvice:
        "Qatlama xamir va quyruq yog'i sababli kaloriyasi yuqori. Tushlik vaqtida yangi ko'katlar bilan iste'mol qilish hazmni yengillashtiradi.",
    ingredients: const [
      IngredientItem(name: "Qatlama xamir", grams: 110, calories: 310),
      IngredientItem(name: "Qiymalangan mol go'shti", grams: 70, calories: 175),
      IngredientItem(name: "Dumba yog'i", grams: 10, calories: 83),
      IngredientItem(name: "Piyoz va ziravorlar", grams: 30, calories: 12),
    ],
  ),
  FoodAnalysisResult(
    dishName: "Tovuqli Sezar salati",
    portionGrams: 280,
    totalCalories: 390,
    proteinGrams: 32.0,
    fatGrams: 18.5,
    carbsGrams: 21.0,
    fiberGrams: 3.8,
    healthScore: 9,
    healthAdvice:
        "Oqsilga juda boy va yengil taom. Kechki ovqat yoki fitnes mashg'ulotlaridan keyin a'lo tanlov.",
    ingredients: const [
      IngredientItem(name: "Grilda pishgan tovuq filesi", grams: 120, calories: 198),
      IngredientItem(name: "Aysberg va Romen salati", grams: 90, calories: 15),
      IngredientItem(name: "Parmezan pishlog'i", grams: 25, calories: 100),
      IngredientItem(name: "Qarsildoq non (krutonlar)", grams: 25, calories: 45),
      IngredientItem(name: "Yengil Sezar sousi", grams: 20, calories: 32),
    ],
  ),
];

// ============================================================================
// ASOSIY EKRAN (HOME SCREEN)
// ============================================================================

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ImagePicker _picker = ImagePicker();

  File? _selectedImageFile;
  Uint8List? _selectedImageBytes;
  bool _isAnalyzing = false;
  String? _errorMessage;

  FoodAnalysisResult? _currentResult;
  List<FoodAnalysisResult> _dailyHistory = [];

  String _apiKey = '';
  int _dailyCalorieGoal = 2200;
  int _selectedTabIndex = 0;

  @override
  void initState() {
    super.initState();
    _loadSavedData();
  }

  Future<void> _loadSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    final savedKey = prefs.getString('gemini_api_key') ?? '';
    final savedGoal = prefs.getInt('daily_calorie_goal') ?? 2200;
    final savedHistoryJson = prefs.getStringList('daily_food_history') ?? [];

    final loadedHistory = <FoodAnalysisResult>[];
    final now = DateTime.now();

    for (final itemStr in savedHistoryJson) {
      try {
        final decoded = jsonDecode(itemStr) as Map<String, dynamic>;
        final entry = FoodAnalysisResult.fromJson(decoded);
        // Faqat bugungi taomlarni kundalikda saqlash
        if (entry.timestamp.year == now.year &&
            entry.timestamp.month == now.month &&
            entry.timestamp.day == now.day) {
          loadedHistory.add(entry);
        }
      } catch (_) {}
    }

    if (mounted) {
      setState(() {
        _apiKey = savedKey;
        _dailyCalorieGoal = savedGoal;
        _dailyHistory = loadedHistory;
      });
    }
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final encoded =
        _dailyHistory.map((item) => jsonEncode(item.toJson())).toList();
    await prefs.setStringList('daily_food_history', encoded);
  }

  Future<void> _pickAndAnalyzeImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        maxWidth: 1280,
        maxHeight: 1280,
        imageQuality: 85,
      );

      if (pickedFile == null) return;

      final bytes = await pickedFile.readAsBytes();
      setState(() {
        _selectedImageFile = File(pickedFile.path);
        _selectedImageBytes = bytes;
        _errorMessage = null;
      });

      await _analyzeWithGemini(bytes);
    } catch (e) {
      setState(() {
        _errorMessage = 'Rasm tanlashda xatolik yuz berdi: $e';
      });
    }
  }

  Future<void> _analyzeWithGemini(Uint8List imageBytes) async {
    if (_apiKey.trim().isEmpty) {
      setState(() {
        _errorMessage =
            'Gemini API kaliti kiritilmagan! Yuqori o\'ng burchakdagi Sozlamalar tugmasi orqali API kalitni kiriting yoki pastdagi "Demo taomni sinash" tugmasidan foydalaning.';
      });
      return;
    }

    setState(() {
      _isAnalyzing = true;
      _errorMessage = null;
    });

    try {
      final model = GenerativeModel(
        model: 'gemini-2.5-flash',
        apiKey: _apiKey.trim(),
        generationConfig: GenerationConfig(
          responseMimeType: 'application/json',
          temperature: 0.2,
        ),
      );

      const prompt = '''
Sen professional diyetolog va nutrisologsan. Rasmda ko'rsatilgan ovqatni diqqat bilan tahlil qil.
Agar rasmda o'zbek milliy taomlari (masalan: palov, somsa, manti, lag'mon, shashlik, chuchvara, mastava, norin, xonim) bo'lsa, ularning an'anaviy tarkibini aniq hisobga ol.

Natijani FAQAT quyidagi JSON formatida o'zbek tilida qaytar:
{
  "dish_name": "Taomning o'zbekcha nomi",
  "portion_grams": 300,
  "total_calories": 550,
  "protein_g": 24.5,
  "fat_g": 22.0,
  "carbs_g": 60.0,
  "fiber_g": 4.0,
  "health_score": 8,
  "health_advice": "Taomning foydali tomonlari va uni qanday iste'mol qilish bo'yicha 1-2 jumlalik aniq tavsiya",
  "ingredients": [
    {
      "name": "Masalliq nomi",
      "grams": 150,
      "calories": 250
    }
  ]
}
''';

      final response = await model.generateContent([
        Content.multi([
          TextPart(prompt),
          DataPart('image/jpeg', imageBytes),
        ]),
      ]);

      final responseText = response.text;
      if (responseText == null || responseText.isEmpty) {
        throw Exception('AI modelidan bo\'sh javob qaytdi.');
      }

      // JSON matnini tozalash va o'qish
      final cleanedJson = responseText
          .replaceAll('```json', '')
          .replaceAll('```', '')
          .trim();

      final Map<String, dynamic> parsed =
          jsonDecode(cleanedJson) as Map<String, dynamic>;
      final result = FoodAnalysisResult.fromJson(parsed);

      setState(() {
        _currentResult = result;
        _isAnalyzing = false;
      });
    } catch (e) {
      setState(() {
        _isAnalyzing = false;
        _errorMessage =
            'Tahlil qilishda xatolik: API kalitingiz to\'g\'riligini va internet aloqasini tekshiring.\nBatafsil: $e';
      });
    }
  }

  void _loadDemoDish(FoodAnalysisResult demo) {
    setState(() {
      _selectedImageFile = null;
      _selectedImageBytes = null;
      _errorMessage = null;
      _currentResult = FoodAnalysisResult(
        dishName: demo.dishName,
        portionGrams: demo.portionGrams,
        totalCalories: demo.totalCalories,
        proteinGrams: demo.proteinGrams,
        fatGrams: demo.fatGrams,
        carbsGrams: demo.carbsGrams,
        fiberGrams: demo.fiberGrams,
        healthScore: demo.healthScore,
        healthAdvice: demo.healthAdvice,
        ingredients: demo.ingredients,
        timestamp: DateTime.now(),
      );
    });
  }

  void _addCurrentToDailyLog() {
    final current = _currentResult;
    if (current == null) return;

    setState(() {
      _dailyHistory.insert(0, current);
    });
    _saveHistory();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${current.dishName} (${current.totalCalories} kkal) kundalikka qo\'shildi!'),
        backgroundColor: const Color(0xFF059669),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  int get _totalCaloriesToday =>
      _dailyHistory.fold(0, (sum, item) => sum + item.totalCalories);

  double get _totalProteinToday =>
      _dailyHistory.fold(0.0, (sum, item) => sum + item.proteinGrams);

  double get _totalFatToday =>
      _dailyHistory.fold(0.0, (sum, item) => sum + item.fatGrams);

  double get _totalCarbsToday =>
      _dailyHistory.fold(0.0, (sum, item) => sum + item.carbsGrams);

  Future<void> _showSettingsDialog() async {
    final apiController = TextEditingController(text: _apiKey);
    final goalController =
        TextEditingController(text: _dailyCalorieGoal.toString());

    await showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.settings_outlined, color: Color(0xFF10B981)),
              SizedBox(width: 8),
              Text('Sozlamalar'),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Gemini API Kaliti',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 6),
                TextField(
                  controller: apiController,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'AIzaSy...',
                    helperText: 'aistudio.google.com saytidan bepul olinadi',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Kunlik kaloriya maqsadi (kkal)',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 6),
                TextField(
                  controller: goalController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: '2200',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Bekor qilish'),
            ),
            FilledButton(
              onPressed: () async {
                final newKey = apiController.text.trim();
                final newGoal =
                    int.tryParse(goalController.text.trim()) ?? 2200;

                final prefs = await SharedPreferences.getInstance();
                await prefs.setString('gemini_api_key', newKey);
                await prefs.setInt('daily_calorie_goal', newGoal);

                if (mounted) {
                  setState(() {
                    _apiKey = newKey;
                    _dailyCalorieGoal = newGoal.clamp(800, 6000);
                  });
                  Navigator.pop(context);
                }
              },
              child: const Text('Saqlash'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFF10B981).withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.restaurant_menu_rounded,
                color: Color(0xFF059669),
                size: 22,
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'Kaloriya AI',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 20,
                color: Color(0xFF0F172A),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'API Kalit va Sozlamalar',
            onPressed: _showSettingsDialog,
            icon: Badge(
              isLabelVisible: _apiKey.isEmpty,
              label: const Text('!'),
              child: const Icon(Icons.key_rounded),
            ),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: IndexedStack(
        index: _selectedTabIndex,
        children: [
          _buildScannerTab(),
          _buildDailyLogTab(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedTabIndex,
        onDestinationSelected: (idx) => setState(() => _selectedTabIndex = idx),
        destinations: [
          const NavigationDestination(
            icon: Icon(Icons.camera_enhance_outlined),
            selectedIcon: Icon(Icons.camera_enhance_rounded),
            label: 'Rasm Tahlili',
          ),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: _dailyHistory.isNotEmpty,
              label: Text('${_dailyHistory.length}'),
              child: const Icon(Icons.pie_chart_outline_rounded),
            ),
            selectedIcon: const Icon(Icons.pie_chart_rounded),
            label: 'Kunlik Hisob',
          ),
        ],
      ),
    );
  }

  // ==========================================================================
  // 1-OYNA: RASMGA OLISH VA AI TAHLIL OYNASI
  // ==========================================================================

  Widget _buildScannerTab() {
    return SingleChildScrollView(
