# Kaloriya AI — Tayyor APK Yig'ish Yo'riqnomasi

Ushbu arxivda **Kaloriya AI** Flutter ilovasining barcha sozlangan kodlari va avtomatik APK yig'ish tizimi jamlangan.

## 1-Usul: Kompyuterga hech narsa o'rnatmasdan (GitHub orqali 3 daqiqada APK olish)
1. [GitHub.com](https://github.com) saytida yangi repozitoriy (masalan, `kaloriya-ai`) yarating.
2. Ushbu arxiv ichidagi barcha fayllarni (`lib/`, `android/`, `.github/`, `pubspec.yaml`) repozitoriyga yuklang.
3. GitHub repozitoriyangizning **Actions** bo'limiga o'ting — u yerda **"Build Kaloriya AI Android APK"** jarayoni avtomatik ishga tushadi.
4. Jarayon yakunlangach (taxminan 2–3 daqiqa), pastdagi **Artifacts** qismidan **`kaloriya-ai-release-apk`** ni yuklab oling — ichida telefonga o'rnatishga tayyor `app-release.apk` bo'ladi!

## 2-Usul: Kompyuterda Flutter SDK orqali APK chiqarish
Agar kompyuteringizda Flutter o'rnatilgan bo'lsa, ushbu papka ichida terminalni ochib quyidagi buyruqlarni bering:

```bash
flutter create --project-name kaloriya_ai .
flutter pub get
flutter build apk --release
```

Tayyor APK fayl manzili: `build/app/outputs/flutter-apk/app-release.apk`
